<?php require_once(APPPATH.'views/include/sub_header.php'); ?>
<div class="grid_3">
  <div class="container">
   <div class="breadcrumb1">
     <ul>
        <a href="index.html"><i class="fa fa-home home_1"></i></a>
        <span class="divider">&nbsp;|&nbsp;</span>
        <li class="current-page">ارتقاء حساب کاربری</li>
     </ul>
   </div>
   <div class="col-md-3 pricing-table">
	  <div class="pricing-table-grid">
		<h3><span class="dollar"> 19,000 </span>تومان<br><span class="month1">عضویت ویژه 1 ماهه</span></h3>
		<ul>
			<li><span>عادی</span></li>
			<li><a href="#"><i class="fa fa-envelope-o icon_3"></i> ایمیل نامحدود </a></li>
			<li><a href="#"><i class="fa fa-phone icon_3"></i> پیام شخصی نا محدود </a></li>
			<li><a href="#"><i class="fa fa-video-camera icon_3"></i> تماس تصویری </a></li>
			<li><a href="#"><i class="fa fa-eye icon_3"></i> مشاهده ایمیل </a></li>
			<li><a href="#"><i class="fa fa-user icon_3"></i> مشاهده شماره همراه </a></li>
			<li><a href="#"><i class="fa fa-smile-o icon_3"></i> مشاهده پروفایل </a></li>
			<li><a href="#"><i class="fa fa-lock icon_3"></i> مشاهده تصاویر </a></li>
			<li><a href="#"><i class="fa fa-smile-o icon_3"></i> ارسال پیامک </a></li>
		</ul>
		<a class="popup-with-zoom-anim order-btn" href="#small-dialog">پرداخت آنلاین</a>
	  </div>
	  
	  </div>
	  <div class="col-md-3 pricing-table">
		<div class="pricing-table-grid">
		  <h3><span class="dollar"> 31,000 </span>تومان<br><span class="month1">عضویت ویژه 3 ماهه</span></h3>
		  <ul>
			<li><span>نقره ای</span></li>
			  <li><a href="#"><i class="fa fa-envelope-o icon_3"></i> ایمیل نامحدود </a></li>
			  <li><a href="#"><i class="fa fa-phone icon_3"></i> پیام شخصی نا محدود </a></li>
			  <li><a href="#"><i class="fa fa-video-camera icon_3"></i> تماس تصویری </a></li>
			  <li><a href="#"><i class="fa fa-eye icon_3"></i> مشاهده ایمیل </a></li>
			  <li><a href="#"><i class="fa fa-user icon_3"></i> مشاهده شماره همراه </a></li>
			  <li><a href="#"><i class="fa fa-smile-o icon_3"></i> مشاهده پروفایل </a></li>
			  <li><a href="#"><i class="fa fa-lock icon_3"></i> مشاهده تصاویر </a></li>
			  <li><a href="#"><i class="fa fa-smile-o icon_3"></i> ارسال پیامک </a></li>

		</ul>
		  <a class="popup-with-zoom-anim order-btn" href="#small-dialog">پرداخت آنلاین</a>
		</div>
	  </div>
	  <div class="col-md-3 pricing-table">
		<div class="pricing-table-grid">
			<h3><span class="dollar"> 42,000 </span>تومان<br><span class="month1">عضویت ویژه 6 ماهه</span></h3>
			<ul>
				<li><span>طلایی</span></li>
				<li><a href="#"><i class="fa fa-envelope-o icon_3"></i> ایمیل نامحدود </a></li>
				<li><a href="#"><i class="fa fa-phone icon_3"></i> پیام شخصی نا محدود </a></li>
				<li><a href="#"><i class="fa fa-video-camera icon_3"></i> تماس تصویری </a></li>
				<li><a href="#"><i class="fa fa-eye icon_3"></i> مشاهده ایمیل </a></li>
				<li><a href="#"><i class="fa fa-user icon_3"></i> مشاهده شماره همراه </a></li>
				<li><a href="#"><i class="fa fa-smile-o icon_3"></i> مشاهده پروفایل </a></li>
				<li><a href="#"><i class="fa fa-lock icon_3"></i> مشاهده تصاویر </a></li>
				<li><a href="#"><i class="fa fa-smile-o icon_3"></i> ارسال پیامک </a></li>
			</ul>
		  <a class="popup-with-zoom-anim order-btn" href="#small-dialog">پرداخت آنلاین</a>
		</div>
	  </div>
	  <div class="col-md-3 pricing-table">
		<div class="pricing-table-grid">
			<h3><span class="dollar"> 57,000 </span>تومان<br><span class="month1">عضویت ویژه 12 ماهه</span></h3>
			<ul>
				<li><span>ویژه</span></li>
				<li><a href="#"><i class="fa fa-envelope-o icon_3"></i> ایمیل نامحدود </a></li>
				<li><a href="#"><i class="fa fa-phone icon_3"></i> پیام شخصی نا محدود </a></li>
				<li><a href="#"><i class="fa fa-video-camera icon_3"></i> تماس تصویری </a></li>
				<li><a href="#"><i class="fa fa-eye icon_3"></i> مشاهده ایمیل </a></li>
				<li><a href="#"><i class="fa fa-user icon_3"></i> مشاهده شماره همراه </a></li>
				<li><a href="#"><i class="fa fa-smile-o icon_3"></i> مشاهده پروفایل </a></li>
				<li><a href="#"><i class="fa fa-lock icon_3"></i> مشاهده تصاویر </a></li>
				<li><a href="#"><i class="fa fa-smile-o icon_3"></i> ارسال پیامک </a></li>
		    </ul>
			<a class="popup-with-zoom-anim order-btn" href="#small-dialog">پرداخت آنلاین</a>
		</div>
	  </div>
	  <div class="clearfix"> </div>
    </div>
</div>
<?php require_once(APPPATH.'views/include/footer.php'); ?>