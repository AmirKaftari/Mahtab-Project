<?php

$pin = "46CAC80AB96CC7D60D6A"; // gateway pin

$url = 'http://panel.donyapay.com/api/verify/'; // don't change
$fields = array(
	'amount' => urlencode($_GET["amount"]),
	'pin' => urlencode($pin),
	'transid' => urlencode($_POST["transid"]),
);
$fields_string = "";
foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
rtrim($fields_string, '&');
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL, $url);
curl_setopt($ch,CURLOPT_POST, count($fields));
curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$result = curl_exec($ch);
curl_close($ch);

echo '<!doctype html>

<html lang="fa">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <title>پرداخت انلاین</title>
  
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/bootstrap-rtl.css">
  <link rel="stylesheet" href="css/stylePage1.css">

  <script src="js/bootstrap.min.js"></script>
<script src="js/jquery-1.11.3.min.js"></script>
</head>

<body style="background-color:#84C0D7">
<div class="container">
    <div class="row">
        <div class="col-md-8 col-lg-push-2">
            <div class="card card-1 " style="padding: 2em; margin: 3em 0">
                <div class="row">
';
if($result == "1"){
    echo '<span style="color:green">پرداخت شما با موفقیت انجام شد !</span>';
} else if ($result == "0") {
echo $result;
   echo '<span style="color:red">متاسفیم! پرداخت شما موفقیت امیز نبود.</span><hr>درصورت کسر شدن موجودی از حسابتان ،‌ظرف ۷۲ ساعت اینده از سمت بانک برگشت داده میشود.';
}
else {
   echo '<span style="color:red">کد خطا : '.$result.'</span>';
}
echo '
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
';
