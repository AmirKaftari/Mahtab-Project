<div class='main'>
        <h2 style="margin-top:0px">Tbl_reort_police اطلاعات</h2>
        <table class="table">
	    <tr><td>idSender</td><td><?php echo $idSender; ?></td></tr>
	    <tr><td>Offending_id</td><td><?php echo $Offending_id; ?></td></tr>
	    <tr><td>Date_Report</td><td><?php echo $Date_Report; ?></td></tr>
	    <tr><td>message</td><td><?php echo $message; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('reort_police') ?>" class="btn btn-default">بازگشت</button></td></tr>
	</table>
    </div>