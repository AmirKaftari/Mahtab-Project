<!--END MAIN WRAPPER -->

<!-- FOOTER -->
<div id="footer">
    <p>کلیه حقوق سایت متعلق به <a href="http://www.eb24.xyz">وب سایت همسریابی و همسان گزینی مهتاب</a> می باشد.</p>
</div>
<!--END FOOTER -->

<!-- GLOBAL SCRIPTS -->
<script src="<?php echo base_url('') ?>assets/dashboard/assets/plugins/jquery-2.0.3.min.js"></script>
<script src="<?php echo base_url('') ?>assets/dashboard/assets/plugins/bootstrap/js/bootstrap.rtl.js"></script>
<script src="<?php echo base_url('') ?>assets/dashboard/assets/plugins/modernizr-2.6.2-respond-1.1.0.min.js"></script>
<script src="<?php echo base_url('') ?>assets/dashboard/assets/plugins/jasny/js/bootstrap-fileupload.js"></script>
<script type="text/javascript" src="<?php echo base_url('assets/datePicker/js/persian-datepicker.js') ?>"></script>
<script src="<?php echo base_url('') ?>assets/js/custom.js"></script>
<script src="<?php echo base_url('') ?>assets/js/chosen.jquery.js"></script>

<script type="text/javascript" src="<?php echo base_url('') ?>assets/date/js/state.js"></script>
<script type="text/javascript" src="<?php echo base_url('') ?>assets/js/parsley.js"></script>
<script type="text/javascript" src="<?php echo base_url('') ?>assets/js/parsley.messages.fa.js"></script>
<script type="text/javascript" src="<?php echo base_url('') ?>assets/js/jquery.flexslider.js"></script>

<script>
    $('.parsley-validate').parsley();
</script>

<script>
    // Can also be used with $(document).ready()
    $(window).load(function() {
        $('.flexslider').flexslider({
            animation: "slide",
            controlNav: "thumbnails"
        });
    });
</script>

<!-- END GLOBAL SCRIPTS -->

<!-- PAGE LEVEL SCRIPTS -->
<script src="<?php echo base_url('') ?>assets/dashboard/assets/plugins/flot/jquery.flot.js"></script>
<script src="<?php echo base_url('') ?>assets/dashboard/assets/plugins/flot/jquery.flot.resize.js"></script>
<script src="<?php echo base_url('') ?>assets/dashboard/assets/plugins/flot/jquery.flot.time.js"></script>
<script  src="<?php echo base_url('') ?>assets/dashboard/assets/plugins/flot/jquery.flot.stack.js"></script>
<script src="<?php echo base_url('') ?>assets/dashboard/assets/js/for_index.js"></script>
<!-- END PAGE LEVEL SCRIPTS -->
</body>

<!-- END BODY -->
</html>
