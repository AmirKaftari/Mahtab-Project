﻿<div class="panel panel-primary">
    <div class="panel-heading">
        <h3 class="panel-title">دسترسی سریع...</h3>
    </div>
    <div class="panel-body" align="center">
        <div class="row" >
            <div class="col-xs-6 col-md-2" >

                <a href="<?php echo base_url('Userinfocontroller/index'); ?>" class="thumbnail">
لیست کاربران<img src="<?php echo base_url('assets/images/users.png') ?>" alt="">
                </a>

            </div>

            <div class="col-xs-6 col-md-2">

                <a href="#" class="thumbnail">
لیست پرداختی ها<img src="<?php echo base_url('assets/images/cost.png') ?>" alt="">
                </a>

            </div>

            <div class="col-xs-6 col-md-2">

                <a href="<?php echo base_url('Reortpolicecontroller'); ?>" class="thumbnail">
گزارشات به پلیس<img src="<?php echo base_url('assets/images/police.png') ?>" alt="">
                </a>

            </div>

            <div class="col-xs-6 col-md-2">

                <a href="<?php echo base_url('Identityusercontroller'); ?>" class="thumbnail">
تاییدهای ارسالی<img src="<?php echo base_url('assets/images/id-card.png') ?>" alt="">
                </a>

            </div>

            <div class="col-xs-6 col-md-2">

                <a href="<?php echo base_url('Uservipcontroller'); ?>" class="thumbnail">
کاربران ویژه<img src="<?php echo base_url('assets/images/vipuser.png') ?>" alt="">
                </a>

            </div>

            <div class="col-xs-6 col-md-2">

                <a href="<?php echo base_url('Usercontroller/index_block'); ?>" class="thumbnail">
کاربران بلاک شده<img src="<?php echo base_url('assets/images/blockuser.png') ?>" alt="">
                </a>

            </div>

        </div>
    </div>
</div>

<!--<div class="panel panel-primary">-->
<!--    <div class="panel-heading">-->
<!--        <h3 class="panel-title">مدیریت محتوا...</h3>-->
<!--    </div>-->
<!--    <div class="panel-body" align="center">-->
<!--        <div class="row" >-->
<!--            <div class="col-xs-6 col-md-2" >-->
<!---->
<!--                <a href="--><?php //echo base_url('Course/create'); ?><!--" class="thumbnail">-->
<!--صفحه درباره ما<img src="--><?php //echo base_url('assets/images/teamwork.png') ?><!--" alt="">-->
<!--                </a>-->
<!---->
<!--            </div>-->
<!---->
<!--            <div class="col-xs-6 col-md-2">-->
<!---->
<!--                <a href="--><?php //echo base_url('Level/create'); ?><!--" class="thumbnail">-->
<!--                    مقالات ازدواج<img src="--><?php //echo base_url('assets/images/lecture.png') ?><!--" alt="">-->
<!--                </a>-->
<!---->
<!--            </div>-->
<!---->
<!--            <div class="col-xs-6 col-md-2">-->
<!---->
<!--                <a href="--><?php //echo base_url('Klass/create'); ?><!--" class="thumbnail">-->
<!--                    قوانین سایت<img src="--><?php //echo base_url('assets/images/rule.png') ?><!--" alt="">-->
<!--                </a>-->
<!---->
<!--            </div>-->
<!---->
<!--            <div class="col-xs-6 col-md-2">-->
<!---->
<!--                <a href="--><?php //echo base_url('Teachers/create'); ?><!--" class="thumbnail">-->
<!--شیوه استفاده<img src="--><?php //echo base_url('assets/images/settings.png') ?><!--" alt="">-->
<!--                </a>-->
<!---->
<!--            </div>-->
<!---->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->